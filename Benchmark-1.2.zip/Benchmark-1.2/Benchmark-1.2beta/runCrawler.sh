#!/bin/sh

mvn test -Pcrawler
